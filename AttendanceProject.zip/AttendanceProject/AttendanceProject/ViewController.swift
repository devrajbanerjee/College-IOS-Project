//
//  ViewController.swift
//  AttendanceProject
//
//  Created by Devraj Banerjee on 2017-08-29.
//  Copyright © 2017 Devraj Banerjee. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet var usernameField: UITextField!    
    @IBOutlet var passwordField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        usernameField.delegate = self
        passwordField.delegate = self
        
    }

    @IBAction func LoginButTapped(_ sender: Any) {
        if usernameField.text == "foo@example.com" && passwordField.text == "password"{
            performSegue(withIdentifier: "Loggedin", sender: self)
            resetField()
        }
    }
    
    @IBAction func ResetTapped(_ sender: Any) {
        resetField()
    }
    
    
    func resetField() {
        usernameField.text = ""
        passwordField.text = ""
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        usernameField.resignFirstResponder()
        passwordField.resignFirstResponder()
        return true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

