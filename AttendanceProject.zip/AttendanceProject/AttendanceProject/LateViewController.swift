//
//  LateViewController.swift
//  AttendanceProject
//
//  Created by Devraj Banerjee on 2017-09-05.
//  Copyright © 2017 Devraj Banerjee. All rights reserved.
//

import UIKit
import MessageUI

class LateViewController: UIViewController, MFMailComposeViewControllerDelegate {

    @IBOutlet var NameField: UITextField!
    @IBOutlet var ReasonField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


    @IBAction func BackTapped(_ sender: Any) {
        performSegue(withIdentifier: "LateToLog", sender: self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func SendTapped(_ sender: Any) {
        let toReceiver = ["devraj.banerjee@triosstudent.com"]
        let mc: MFMailComposeViewController = MFMailComposeViewController()
        mc.mailComposeDelegate = self
        mc.setToRecipients(toReceiver)
        mc.setSubject("\(NameField.text!) coming late")
        mc.setMessageBody("Name : \(NameField.text!) \n\nReason for Late : \(ReasonField.text!)", isHTML: false)
        self.present(mc, animated: true, completion: nil)
    }

    @IBAction func dismissKeyboard(_ sender: Any) {
        self.resignFirstResponder()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
