//
//  AbsentViewController.swift
//  AttendanceProject
//
//  Created by Devraj Banerjee on 2017-09-06.
//  Copyright © 2017 Devraj Banerjee. All rights reserved.
//

import UIKit
import MessageUI

class AbsentViewController: UIViewController, MFMailComposeViewControllerDelegate {

    @IBOutlet var NameTextField: UITextField!    
    @IBOutlet var ReasonTextField: UITextField!
    @IBOutlet weak var FromDateLbl: UILabel!
    @IBOutlet weak var ToDateLbl: UILabel!
    @IBOutlet weak var FromDatePkr: UIDatePicker!
    @IBOutlet weak var ToDatePkr: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let  formatter = DateFormatter()
        formatter.dateFormat = "dd/MMM/yyyy"
        FromDateLbl.text = formatter.string(from: FromDatePkr.date)
        ToDateLbl.text = formatter.string(from: ToDatePkr.date)
    }

    @IBAction func BackTapped(_ sender: Any) {
        performSegue(withIdentifier: "AbsentToLog", sender: self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func FrmDtPkr(_ sender: Any) {
        let  formatter = DateFormatter()
        formatter.dateFormat = "dd/MMM/yyyy"
        FromDateLbl.text = formatter.string(from: FromDatePkr.date)
    }

    @IBAction func ToDtPkr(_ sender: Any) {
        let  formatter = DateFormatter()
        formatter.dateFormat = "dd/MMM/yyyy"
        ToDateLbl.text = formatter.string(from: ToDatePkr.date)
    }
    @IBAction func SendTapped(_ sender: Any) {
        let Toreceiver = ["devraj.banerjee@triosstudent.com"]
        let mc: MFMailComposeViewController = MFMailComposeViewController()
        mc.mailComposeDelegate = self
        mc.setToRecipients(Toreceiver)
        mc.setSubject("\(NameTextField.text!) is on vacation from \(FromDateLbl.text!)")
        mc.setMessageBody("Name :\(NameTextField.text!)\n\nVacation From: \(FromDateLbl.text!)\n\nVacation To: \(ToDateLbl.text!)\n\nReason: \(ReasonTextField.text!)", isHTML: false)
        self.present(mc, animated: true, completion: nil)
    }
    
    @IBAction func DismissKB(_ sender: Any) {
        self.resignFirstResponder()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
