//
//  GeoViewController.swift
//  AttendanceProject
//
//  Created by Devraj Banerjee on 2017-09-05.
//  Copyright © 2017 Devraj Banerjee. All rights reserved.
//

import UIKit
import MapKit

class GeoViewController: UIViewController {

    @IBOutlet var Map: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    let region: MKCoordinateRegion = MKCoordinateRegionMake(CLLocationCoordinate2D.init(latitude: 43.5935094, longitude: -79.6403932), MKCoordinateSpanMake(0.01, 0.01))
    
    
    

    @IBAction func BackButTapped(_ sender: Any) {
        performSegue(withIdentifier: "GeoToLog", sender: self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
